package com.kiranacademy.productapi;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("categoryapi")
public class CategoryController {
	
	@Autowired
	SessionFactory factory;
	
	@GetMapping("category/{cid}")
	public Category getCategory(@PathVariable int cid)
	{	
		Session session = factory.openSession();
		
		Category category = session.load(Category.class, cid);
		
		return category;
		
	}
	
	@GetMapping("category")
	public List<Category> getAllCategory()
	{
		Session session = factory.openSession();
		
		Query query = session.createQuery("from Category");
		
		List<Category> list = query.list();
		
		return list;
	}
	
	@PostMapping("category")
	public Category addCategory(@RequestBody Category category)
	{	
		Session session = factory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		session.save(category);
		
		tx.commit();
		
		System.out.println(category);
		
		return category;
	}
	
	@DeleteMapping("category/{cid}")
	public String deleteCategory(@PathVariable int cid)
	{	
		Session session = factory.openSession();
		
		Category category = session.load(Category.class, cid);
		
		Transaction tx = session.beginTransaction();
				session.delete(category);
				
		tx.commit();
		
		return "Record Deleted";
		
	}
	
	@PutMapping("category")
	public String updateCategory(@RequestBody Category clientCategory)
	{	
		Session session = factory.openSession();
		
		Category category = session.load(Category.class, clientCategory.getCid());
		
		category.setName(clientCategory.getName());
		
		Transaction tx = session.beginTransaction();
		
		session.update(category);
		
		tx.commit();
		
		return "Record Updated";
		
	}

}
	
