package com.kiranacademy.productapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
